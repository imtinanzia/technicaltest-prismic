import { renderHook, act } from "@testing-library/react";
import { vi } from "vitest";
import { useSliceStore } from ".";

describe("useSliceStore", () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  test("should have initial state with empty slices array", () => {
    const { result } = renderHook(() => useSliceStore());
    expect(result.current?.slices).toEqual([]);
  });

  test("should update slices state correctly with setSlices", () => {
    const { result } = renderHook(() => useSliceStore());
    const mockSlices = [
      {
        id: "1",
        label: "test label 1",
        fields: [{ type: "text", placeholder: "Text Input", value: "" }],
      },
      {
        id: "2",
        label: "test label 2",
        fields: [{ type: "text", placeholder: "Text Input", value: "" }],
      },
    ];
    act(() => {
      result.current?.setSlices(mockSlices);
    });
    expect(result.current?.slices).toEqual(mockSlices);
  });

  test("should replace previous slices with new array when using setSlices", () => {
    const { result } = renderHook(() => useSliceStore());
    act(() => {
      result.current.setSlices([
        {
          id: "1",
          label: "test label 1",
          fields: [{ type: "text", placeholder: "Text Input", value: "" }],
        },
      ]);
    });
    act(() => {
      result.current.setSlices([
        {
          id: "2",
          label: "test label 2",
          fields: [{ type: "text", placeholder: "Text Input", value: "" }],
        },
      ]);
    });

    expect(result.current?.slices).toEqual([
      {
        id: "2",
        label: "test label 2",
        fields: [{ type: "text", placeholder: "Text Input", value: "" }],
      },
    ]);
  });

  test("should load persisted state correctly and update it", () => {
    const persistedState = [
      {
        id: "2",
        label: "test label 2",
        fields: [{ type: "text", placeholder: "Text Input", value: "" }],
      },
    ];

    // Mock the persist function
    const persistMock = vi.fn((callback) => {
      const set = vi.fn();
      callback(set);
      set(persistedState);
    });

    persistMock((set: () => void) => set);

    const { result } = renderHook(() => useSliceStore());

    // Assert the persisted state is loaded correctly
    expect(result.current.slices).toEqual(persistedState);

    const mockSlices = [
      {
        id: "3",
        label: "test label 3",
        fields: [{ type: "text", placeholder: "Text Input", value: "" }],
      },
    ];
    act(() => {
      result.current.setSlices(mockSlices);
    });

    // Assert the persist function is called with the updated state
    expect(persistMock).toHaveBeenCalled();
    expect(result.current.slices).toEqual(mockSlices);
  });
});
