import { persist } from 'zustand/middleware';
import { create } from 'zustand';
import { ISlice } from '../types';

interface SliceState {
  slices: ISlice[];
  setSlices: (slices: ISlice[]) => void;
}

export const useSliceStore = create<SliceState>()(
  persist(
    (set) => ({
      slices: [],
      setSlices: (slices: ISlice[]) => set({ slices }),
    }),
    {
      name: 'slice-store',
    }
  )
);
