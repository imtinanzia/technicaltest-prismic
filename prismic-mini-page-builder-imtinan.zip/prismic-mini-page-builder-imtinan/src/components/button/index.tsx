import * as React from "react";
import "./button.css";

interface ButtonProps extends React.ComponentProps<"button"> {
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ children, ...props }) => {
  return <button {...props}>{children}</button>;
};
ghgh