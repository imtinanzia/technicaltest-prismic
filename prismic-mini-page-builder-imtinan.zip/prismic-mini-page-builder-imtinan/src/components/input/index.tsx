import "./input.css";

export const Input: React.FC<React.ComponentProps<"input">> = (props) => {
  return <input {...props} />;
};
