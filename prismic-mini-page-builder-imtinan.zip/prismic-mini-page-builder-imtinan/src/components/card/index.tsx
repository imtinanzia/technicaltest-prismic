import * as React from "react";
import { AddIcon } from "../../assets/Add";
import "./card.css";

type Variant = "primary" | "secondary" | "default";

interface CardProps extends React.ComponentProps<"article"> {
  variant: Variant;
  label: string;
  dataTestId: string;
}

export const Card: React.FC<CardProps> = ({
  variant = "primary",
  label,
  dataTestId,
  onClick,
}) => {
  return (
    <article
      className="card-wrapper"
      onClick={onClick}
      data-testid={dataTestId}
    >
      <div className={`${variant}-card`}>
        <AddIcon />
      </div>
      <label>{label}</label>
    </article>
  );
};
