import { render, fireEvent, cleanup } from "@testing-library/react";
import { Home } from "./home";

afterEach(cleanup);

describe("Home Component", () => {
  test("renders the component properly", () => {
    const { getByText } = render(<Home />);
    expect(getByText("Available Slices")).toBeInTheDocument();
  });

  test("adds a new slice on card click", async () => {
    const { getByText, getByTestId } = render(<Home />);
    const heroCard = getByTestId("hero-testid");
    fireEvent.click(heroCard);

    expect(getByText("Hero Slice")).toBeInTheDocument();

    const textFieldInputs = document.querySelectorAll(
      'input[type="text"][placeholder="Text Input"]'
    );
    expect(textFieldInputs.length).toBe(2);
  });

  test("removes a slice on slice remove click", () => {
    const { getByTestId } = render(<Home />);

    const removeButton = getByTestId("remove-slice-btn");
    fireEvent.click(removeButton);
    expect(removeButton).not.toBeInTheDocument();
  });

  test("updates slice field value on input change", () => {
    const { getByTestId, getAllByPlaceholderText } = render(<Home />);
    const heroCard = getByTestId("hero-testid");
    fireEvent.click(heroCard);

    const input = getAllByPlaceholderText("Text Input")[0] as HTMLInputElement;
    fireEvent.change(input, { target: { value: "New Value" } });
    expect(input?.value).toBe("New Value");
  });

  test("does not update slice field value when input is negative for number type", () => {
    const { getByText, getByPlaceholderText } = render(<Home />);
    const priceCard = getByText("Price");
    fireEvent.click(priceCard);
    const numberInput = getByPlaceholderText(
      "Number Input"
    ) as HTMLInputElement;
    fireEvent.change(numberInput, { target: { value: -10 } });
    expect(numberInput?.value).toBe("");
  });

  test("set error message for negative number when input is negative for number type", () => {
    const { getByText, getByPlaceholderText } = render(<Home />);
    const numberInput = getByPlaceholderText(
      "Number Input"
    ) as HTMLInputElement;
    fireEvent.change(numberInput, { target: { value: -5 } });

    // Assert
    expect(numberInput.value).toBe("");
    expect(getByText("Number should not be negative")).toBeInTheDocument();
  });
});
