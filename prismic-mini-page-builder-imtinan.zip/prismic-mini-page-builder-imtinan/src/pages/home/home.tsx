import * as React from "react";
import { Card } from "../../components";
import { Slice } from "./slice";
import { useSliceStore } from "../../store";
import { FieldType, ISlice } from "../../types";
import { getTextField, generateUid } from "../../utils";
import "./home.css";

export const Home = () => {
  const { slices, setSlices } = useSliceStore();

  const handleAddSlice = (label: string, ...fields: FieldType[]) => {
    const id = generateUid();
    let slicesClone = slices;
    slicesClone = [
      ...slicesClone,
      {
        id,
        label,
        fields,
      },
    ];
    setSlices(slicesClone);
  };

  const handleRemoveSlice = (index: number) => {
    const slicesClone = slices.filter((_: ISlice, i: number) => i !== index);
    setSlices(slicesClone);
  };

  const handleOnChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
    fieldIndex: number,
    errorChange: (value: string, index: number | undefined) => void
  ) => {
    const { value, type } = e.target;

    //create a deep copy
    const slicesClone = JSON.parse(JSON.stringify(slices));

    if (type === "number" && parseInt(value) < 0) {
      errorChange("Number should not be negative", fieldIndex);
      return;
    }

    slicesClone[index].fields[fieldIndex]["value"] = value;

    errorChange("", undefined);
    setSlices(slicesClone);
  };

  return (
    <React.Fragment>
      {slices?.map(
        (slice: ISlice, index: number): JSX.Element => (
          <Slice
            key={slice.id}
            heading={slice.label}
            fields={slice?.fields}
            index={index}
            onChange={handleOnChange}
            handleRemoveSlice={handleRemoveSlice}
          />
        )
      )}

      <h2 className="title">Available Slices</h2>
      <div className="cards-container">
        <Card
          label="Hero"
          variant="primary"
          dataTestId="hero-testid"
          onClick={() =>
            handleAddSlice(
              "Hero Slice",
              getTextField("text", "Text Input", ""),
              getTextField("text", "Text Input", "")
            )
          }
        />
        <Card
          label="Article"
          variant="secondary"
          dataTestId="article-testid"
          onClick={() =>
            handleAddSlice(
              "Article Slice",
              getTextField("text", "Text Input", ""),
              getTextField("text", "Text Input", ""),
              getTextField("color", "", "#e9f9ee")
            )
          }
        />
        <Card
          label="Price"
          variant="default"
          dataTestId="price-testid"
          onClick={() =>
            handleAddSlice(
              "Price Slice",
              getTextField("text", "Text Input", ""),
              getTextField("number", "Number Input", "")
            )
          }
        />
      </div>
    </React.Fragment>
  );
};
