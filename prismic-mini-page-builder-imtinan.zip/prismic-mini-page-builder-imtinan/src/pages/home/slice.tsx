import { FieldType } from "../../types";
import { Button, Input } from "../../components";
import "./home.css";
import { useState } from "react";

interface SliceProps {
  heading: string;
  fields?: FieldType[];

  index: number;
  onChange: (
    e: React.ChangeEvent<HTMLInputElement>,
    index: number,
    fieldIndex: number,
    errorChange: (value: string, index: number | undefined) => void
  ) => void;
  handleRemoveSlice: (index: number) => void;
}

interface FieldProps {
  error: string;
  index: number | undefined;
}

export const Slice: React.FC<SliceProps> = ({
  heading,
  fields,
  index,
  onChange,
  handleRemoveSlice,
}) => {
  const [error, setError] = useState<FieldProps>({
    error: "",
    index: undefined,
  });

  const errorChange = (error: string, index: number | undefined) => {
    setError({ error, index });
  };

  return (
    <div className="slice-wrapper">
      <div className="slice-header">
        <h2>{heading}</h2>
        <Button
          data-testid="remove-slice-btn"
          onClick={() => handleRemoveSlice(index)}
        >
          Remove Slice
        </Button>
      </div>
      <div className="slice-body">
        {fields?.map((field, currIndex) => (
          <div key={currIndex + 1}>
            <Input
              type={field.type}
              placeholder={field.placeholder}
              value={field.value}
              onChange={(e) => onChange(e, index, currIndex, errorChange)}
            />
            {error.index === currIndex && (
              <span className="error-msg">{error.error}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
