import { render, fireEvent } from "@testing-library/react";
import { Slice } from "./slice";
import { vi } from "vitest";
import { FieldType } from "../../types";

describe("Slice component", () => {
  const mockFields: FieldType[] = [
    { type: "text", placeholder: "Enter text", value: "Test" },
    { type: "number", placeholder: "Enter number", value: 10 },
  ];

  const mockOnChange = vi.fn();
  const mockHandleRemoveSlice = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders the component with heading and fields", () => {
    const heading = "Test Slice";
    const index = 0;

    const { getByText, getAllByPlaceholderText } = render(
      <Slice
        heading={heading}
        fields={mockFields}
        index={index}
        onChange={mockOnChange}
        handleRemoveSlice={mockHandleRemoveSlice}
      />
    );

    // Assert the heading is rendered correctly
    expect(getByText(heading)).toBeInTheDocument();

    const inputElements = getAllByPlaceholderText(
      /Enter/i
    ) as HTMLInputElement[];

    // Assert all fields are rendered correctly
    expect(inputElements).toHaveLength(mockFields.length);
    expect(inputElements[0]?.value).toBe(mockFields[0]?.value.toString());
    expect(inputElements[1]?.value).toBe(mockFields[1]?.value.toString());
  });

  it("calls onChange when input value changes", () => {
    const { getAllByPlaceholderText } = render(
      <Slice
        heading="Test Slice"
        fields={mockFields}
        index={0}
        onChange={mockOnChange}
        handleRemoveSlice={mockHandleRemoveSlice}
      />
    );

    const inputElements = getAllByPlaceholderText(
      /Enter/i
    )[0] as HTMLInputElement;
    fireEvent.change(inputElements, { target: { value: "Updated text" } });

    // Assert that onChange is called with the correct arguments
    expect(mockOnChange).toHaveBeenCalledTimes(1);
  });

  it("calls handleRemoveSlice when Remove Slice button is clicked", () => {
    const { getByText } = render(
      <Slice
        heading="Test Slice"
        fields={mockFields}
        index={0}
        onChange={mockOnChange}
        handleRemoveSlice={mockHandleRemoveSlice}
      />
    );

    const removeButton = getByText("Remove Slice");
    fireEvent.click(removeButton);

    // Assert that handleRemoveSlice is called with the correct index
    expect(mockHandleRemoveSlice).toHaveBeenCalledTimes(1);
    expect(mockHandleRemoveSlice).toHaveBeenCalledWith(0);
  });
});
