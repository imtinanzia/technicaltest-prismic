export const AddIcon = () => {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      color="transparent"
    >
      <circle cx="8" cy="8" r="8" fill="#E1E1E1" />
      <path
        d="M13.0905 8.72723H8.72687V13.0909H7.27233V8.72723H2.90869V7.27269H7.27233V2.90905H8.72687V7.27269H13.0905V8.72723Z"
        fill="white"
      />
    </svg>
  );
};
