export type FieldType = {
  type: string;
  placeholder: string;
  value: string | number;
};

export interface ISlice {
  id: string | undefined;
  label: string;
  fields: FieldType[];
}
